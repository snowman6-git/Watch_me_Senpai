import requests, json
from bs4 import BeautifulSoup
import hashlib


headers = {
    "message": 'wkatlaksqlfflfrpdy',
    "Origin": "http://attend.yc.ac.kr:18080",
    "Connection": "keep-alive",  # 연결 유지
    "Content-Length": "25",  # 요청 본문의 길이
    "Accept": "*/*",  # 모든 콘텐츠 타입 허용
    "X-Requested-With": "XMLHttpRequest",  # XMLHttpRequest를 통해 요청
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",  # 요청 본문의 콘텐츠 타입
    "Accept-Encoding": "gzip, deflate",  # 압축된 응답 허용
    "Accept-Language": "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7",  # 언어 설정 (한국어, 영어)
    "User-Agent": "Mozilla/5.0 (Linux; Android 9; SM-G998B Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/126.0.6478.122 Safari/537.36",
}

def ym(id, pw):
    # print(id, pw)
    login_url = "http://portal.yc.ac.kr/enview/user/loginProcess.face"
    session = requests.Session()
    payload = {
        "userId" : id,
        "password" : pw,
    }
    response = session.post(login_url, data=payload)#, headers=headers)
    if response.ok:
        soup = BeautifulSoup(response.text, 'html.parser')
        name_tag = soup.select_one('p', class_='name').get_text(strip=True).split("(")[0]
        return name_tag
    else:
        print(response.status_code)
        return False